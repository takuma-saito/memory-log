SNR (Search 'N' Replace) 6.1 for Windows95

Copyright (c) 1997 Thomas A. Lundin
ALL RIGHTS RESERVED.

Distributed as fully-functional SHAREWARE. ($60 + s/h).

SNR is a multi-string, multi-file search and replace utility. It will 
convert text and binary files of any size. SNR allows up to 2,500 
conversion "equations" to be defined in a search-and-replace table; 
these equations will be performed at one time on each file to be 
converted. Multiple conversion tables may be chained in sequence. SNR 
has advanced search-and-replace features such as wild card pattern 
matching and variable-length string pattern matching.

Examples of the application of SNR are: automating the coding of 
data files for desktop publishing; HTML tagging; making global source 
code changes; converting Rich Text Format word processing files; 
preparing uncoded ASCII files for word processing, desktop publishing or 
web; filtering e-mail files. And much, much more.

Registration may be sent to the author:

Thomas A. Lundin
16267 Hudson Avenue
Lakeville, MN 55044

phone: 612-431-5805
email: 70523.262@compuserve.com

------------------------------------------------------------------

Included in this .ZIP file are:

-> SNR.EXE, the shareware 16-bit version of SNR 5.08 that will run on 
   286 and higher models of IBM-PC compatible computers.

-> SNR32.EXE, the shareware 32-bit version of SNR 6.1 specifically 
   compiled for command-line use in DOS mode under Windows95 or NT. 
   SUPPORTS WINDOWS95/NT LONG FILENAMES! Requires 486 or higher 
   processor.

-> SNR95.EXE, the shareware 32-bit version of SNR 6.1 for use under 
   Windows95 or NT. Supports long filenames. Requires 486 or higher 
   processor.
------------------------------------------------------------------

Files comprising the shareware distribution package for SNR 6.1

README.TXT...........The file you're looking at now
ORDERFRM.DOC ........Registration order form
DEMO.BAT ............Runs a test file through a series of tables for you.
                     To invoke the demo, just type DEMO
SNR32.EXE ...........The command-line version of SNR 6.1
SNR95.EXE ...........The GUI-mode version of SNR 6.1
SNR.DOC .............The user manual
QUIKREF.DOC .........Quick reference command sheet

DEMOTEST ............Test file for DEMO.BAT
FIXED ...............Test file for FIXED2CR.S
PENTATST ............Test file for NOCODES.S
TABTEST .............Test file for SPC2TAB.S
MERGE ...............Test file for SDF2FIX.S

The following sample tables may be run as is, or you can modify them for your 
own purposes. Read each of them before running them to see what they are 
supposed to do; then run them on some test files of yours to see the result of 
the conversion. It's easier to understand a translation table once you know 
what it does. 

ADDLF.S .............Add line feeds to carriage returns
ASC2EBC.S ...........ASCII-to-EBCDIC table
ASC2VP.S ............ASCII to Ventura Publisher special codes
CAP2LC1.S ...........Makes an all-upper case file upper and lower case
CAP2LC2.S ...........Cleanup table for upper and lower case conversion
CHOP.S ..............Strips the 8th bit from all characters
COMPRESS.S ..........Compresses multiple adjacent spaces
DECRYPT.S ...........Unscrambles a file encrypted with ENCRYPT.S
EBC2ASC.S ...........EBCDIC-to-ASCII table
EL2ONE.S ............Changes letters l and O to numerals 1 and 0
ENCRYPT.S ...........Purposely scrambles a file for security
EVERY5.S ............Outputs a special tag every five lines
FIXED2CR.S ..........Turns a fixed-length data file into ASCII text lines
LC2CAP.S ............Makes all letters upper case
NOCODES.S ...........Removes Penta Systems typesetting codes
NONONASC.S ..........Removes all non-ASCII characters
PARATAG.S ...........Distinguishes ASCII paragraphs from line-for-line text
QUOTES.S ............Makes the double-quote character left- and right-facing
SDF2FIX.S ...........Turns comma-delimited fields into fixed-length fields
SHAVE.S .............Removes the first 256 characters from any file
SINGLESP.S ..........Turns a double-spaced document into a single-spaced one
SPC2TAB.S ...........Converts three or more spaces into a tab code
SPELL.S .............Corrects some commonly-misspelled words
SWAPTABS.S ..........Transposes variable-length tab columns
TABULAR.S ...........Places tab codes between fixed-length columns
TABULAR2.S ..........Pass 2 cleanup for TABULAR.S
TRUNCATE.S ..........Truncates a file upon encountering an end-of-file char.
VARIABLE.S ..........Sample equations for variable-length search & replace
VTYPE.S .............Clearly shows all non-ASCII characters in a file
WORDWRAP.S ..........Word wrap a file that contains long text lines
WS2PLAIN.S ..........Wordstar to ASCII; ignores dot commands, too.


